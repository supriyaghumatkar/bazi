<?php include 'header.php'; ?>
<?= $contents ?>
<?php include 'footer.php'; ?>